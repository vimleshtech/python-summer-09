
#empty list 
sales  = []

#wap to enter amt for 12 months

i =1
while i<=12:

     amt  = input('enter amt :') #default input type is string
     
     sales.append(int(amt))  #convert to int before store in list 

     i =i+1


print(sales)

t= sum(sales)
m = max(sales)
mi = min(sales)

print(t)
print(m)
print(mi)




