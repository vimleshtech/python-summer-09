
#wap to take sale amt amount show the tax if amt is greater than 1000

amt   = int(input('enter amt :'))

tax = 0
if amt>1000:
     tax = amt*.18

elif amt>500:
     tax = amt*.12
elif amt>100:
     tax = amt*.10
else:
     tax = amt*.05
     
     
total = amt+tax
print('total amt is ',total)



     
