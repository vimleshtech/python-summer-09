#import modules
import pandas
import matplotlib.pyplot as plt
#from pandas.tools.plotting import scatter_matrix

#read/load data 
url = r"C:\Users\vkumar15\Desktop\Learning & Training\Project\iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pandas.read_csv(url, names=cols)

print(dataset)
print(dataset.shape)
print(dataset.columns)

print(dataset.head())
print(dataset.tail())
print(dataset.info())

print(dataset.describe()) #show stats 

# class distribution
print(dataset.groupby('class').size())

# box and whisker plots
#dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
dataset.hist()
plt.show()


c = dataset.corr()
c.to_csv('corr.csv')












