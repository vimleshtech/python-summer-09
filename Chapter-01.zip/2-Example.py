x = input('enter data ')
y = input('enter data ')

print(type(x))
print(type(y))

#convert string to int
x = int(x)
y  = int(y)


print(type(x))
print(type(y))


z = x+y
print(z)


