
import os

o = os.listdir(r'C:\Users\hp\Desktop')
print(o)

print(len(o))

tc = 0
for r in o:
        #print(r)
        if r.endswith('.txt'):
                print(r)
                tc+=1

print(tc)


                
                
