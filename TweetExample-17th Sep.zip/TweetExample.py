import tweepy
import textblob
import re

#from textblob import TextBlob #text/tweet parse

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"


auth = tweepy.OAuthHandler(ck, cs)
# set access token and secret
auth.set_access_token(at, ats)

# create tweepy API object to fetch tweets
api = tweepy.API(auth)

print('login pass')

def getSentiment(tweet):     
        analysis = textblob.TextBlob(tweet)
        #print(analysis)
        #print(analysis.sentiment.polarity)
        
        # set sentiment
        if analysis.sentiment.polarity > 0:
            return 'positive'
        elif analysis.sentiment.polarity == 0:
            return 'neutral'
        else:
            return 'negative'
        
#create the tweet
def clean_tweet(tweet):
    return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split())

def get_tweet(l,c=10):
    #find /get tweets
    out = api.search(q=l,count=c)
    print('------',l,'-------')
    tl = []
    for t in out:
        try:
            #print(getSentiment(clean_tweet(t.text)))
            tl.append(getSentiment(clean_tweet(t.text)))
        except:
            pass
                
    return tl

##
leaders =["Sonia Gandhi","Rahul Gandhi","Narendra Modi"]
for l in leaders:
          tl =get_tweet(l,200)
          #print(tl)

          p =0
          n =0
          ne = 0
          for t in tl:
              if t=='positive':
                  p+=1
              elif t=='negative':
                  n+=1
              else:
                  ne+=1

          print(p,n,ne)
          print((p/len(tl))*100,(n/len(tl))*100,(ne/len(tl))*100)

                  
                  


                  


          
          
          
          







