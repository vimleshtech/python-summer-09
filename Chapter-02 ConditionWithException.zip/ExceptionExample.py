try:
     a = int(input('enter data :'))
     b = int(input('enter data :'))

     if b<0:
          m = ZeroDivisionError('divisor cannot be less than 0')
          raise m#""#go to 
          
     x = a/b
     print(x)
except NameError as x:
     print('variable name is not defined')
except ZeroDivisionError as y:
     #print(y)
     pass
     #print('number cannot be divided by 0')     
except:
     print('there is some technical error')

finally:
     print('thank u for using system... end of program')
     


