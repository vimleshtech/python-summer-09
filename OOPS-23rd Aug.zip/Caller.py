from Employee4 import contractor

c = contractor()
c.newemp()
c.compute()
c.disp()
c.working_days('aa')


