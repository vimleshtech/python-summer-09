'''
123      3 rows, 3 cols 
123
123
-----
1
12
123
1234
12345
'''

#r =1 , c = 1 2 3
#r =2 , c = 1 2 3
#r =3 , c = 1 2 3

'''
111
222
333
'''
for r in range(1,4): #from 1 to 3
    for c in range(1,4):
        print(c,end='') #don't change line

    #if r ==2:
    
    print() #new line


for r in range(1,10):
    for c in range(1,r+1):
        #print(c,end='') #don't change line
        print('*',end='') #don't change line
    
    
    print() #new line
    
for r in range(1,10):
    for c in range(1,r+1):
        #print(c,end='') #don't change line
        print(c,end='') #don't change line
    
    
    print() #new line
  

    
        
        
    
