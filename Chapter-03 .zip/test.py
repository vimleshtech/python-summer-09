
print('hello')


for i in range(1,11):
     print(i)
     
for i in range(51,91,1):
      print(i)
