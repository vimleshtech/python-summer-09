for r in range(1,3):
     for c in range(1,4):
          #print(c)  #print and new line
          print(c,end='\t') #print and don't change line
     print() #new line 
          
          

#

for r in range(1,5):
     for c in range(1,5):
          #print(c)  #print and new line
          print(c,end='') #print and don't change line
     print() #new line 

#
for r in range(1,5): # 1 to 4 
     for c in range(1,r+1): #c condition is depends on r value  1,2 = 1 to 1 
          #print(c)  #print and new line
          print(c,end='') #print and don't change line
     print() #new line 

