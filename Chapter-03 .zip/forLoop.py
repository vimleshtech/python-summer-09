for x in range(10):
     print(x)


#
for x in range(0,10):
     print(x)


#
for x in range(0,10,1):
     print(x)

#
for x in range(0,10,2):
     print(x)
     
     
#in reverse order
for i in range(10,0,-1):
     print(i)
     
