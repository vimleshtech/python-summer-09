i =1  
while i<=100:
     print(i)
     i =i+1


#print in reverse
i =100
while i>0:
     print(i)
     i  = i-1

#get all odd numbers
i =1
while i<=20:
     print(i)
     i =i+2
     
     
     
     
     
