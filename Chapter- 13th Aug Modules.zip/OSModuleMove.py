
import os
import shutil

o = os.listdir(r'C:\Users\hp\Desktop')


for r in o:
        #print(r)
        if r.endswith('.txt'):
                shutil.copy(r'C:\Users\hp\Desktop\\'+r,r'C:\Users\hp\Desktop\out')
                


                
                
