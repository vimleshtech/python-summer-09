#append()  # add new data at last
#pop()  #remove from last
#remove() #find and remove
#slicer  #return value by given index range

#CRUD : create, read, update, delete 

data = [] #empty list

while True : #infinite loop

    ch = input('press 1 for add 2 for show 3 for remove 4 for update and 0 for exit')
    if ch =='1':
        d = input('enter value :')
        data.append(d)        
    elif ch =='2':
        print(data)
    elif ch =='3':
        d = input('enter value to remove :')
        if d in data:
            data.remove(d)
        else:
            print('Given value is not found')

    elif ch =='4':
            d = input('enter existing value ')
            for i in range(0,len(data)):
                if data[i] == d:
                    nd = input('enter new value :')
                    data[i] = nd 
                
                
                
    elif ch == '0':
        print('Thank you !!!')
        break 
    else:
        print('Invalid choice, plz try again !!!')
        


        
    
