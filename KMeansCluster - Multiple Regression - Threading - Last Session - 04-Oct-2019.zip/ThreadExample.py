'''
Thread : is process
Multiple Thread : multiple process

'''
import time
import threading

def process1():
    for i in range(1,5):
        print(i)
        #time.sleep(3)

def process2():
    for i in range(11,15):
        print(i)
        #time.sleep(3)




#process1()
#process2()
p1=  threading.Thread(target=process1,name='p1')
p2= threading.Thread(target=process2,name='p2')
p1.start()
p2.start()




    
