import mysql.connector as c

con=c.connect(host='localhost', user='root',password='',database='test')
cur=con.cursor()

try:

    cur.execute('create table aks(id int, name varchar(100));')
    con.commit()
    

except:
    pass


def save_data():
    i= input('enter id :')
    n= input('enter id :')

    cur.execute("insert into aks(id,name) values({},'{}')".format(i,n))
    con.commit()
    print('data is saved')

def get_data():
    cur.execute('select * from aks')

    data=cur.fetchall()
    for r in data:
        print(r)

while True:
    ch = input('press 1 to save data 2 for show 3 for exit')
    if ch =='1':
        save_data()
    elif ch=='2':
        
        get_data()
    elif ch=='0':
        break
    else:



        print('invalid choice , plz try again')



#delete from tablename;
#delete from tablename where id =1;
        
#delete from tablename where bane ='jatin';

        
        
