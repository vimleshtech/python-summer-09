'''
i =1 #init
while i<10: #condition 
    if i% 3 ==0: #condition 
        continue

    print(i)
    i=i+1
'''
#range(10)  0 1 2 .. 9
#range(1,10)   1 2 .. 9
#range(1,10,1)   1 2 .. 9
#range(1,10,2)   1 3 5 7 9

for i in range(10): #default incrementer is 1
    if i% 3 ==0: #condition 
        continue

    print(i)
    i=i+1

'''    
while True:
    print('hi')
    
'''




for r in range(1,10):
    for c in range(1,r+1):
        #print(c,end='') #don't change line
        print('c',end='') #don't change line
    
    
    print() #new line
  





