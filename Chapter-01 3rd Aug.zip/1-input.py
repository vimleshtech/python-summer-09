# comment

a = input('enter data :')
b = input('enter data :')


print(type(a)) #show data type
print(type(b)) #show data type


#addition
c = a+b
print(c)

####################
#type casting / convert to int
a = int(a)
b = int(b)


print(type(a)) #show data type
print(type(b)) #show data type


#addition
c = a+b
print(c)





