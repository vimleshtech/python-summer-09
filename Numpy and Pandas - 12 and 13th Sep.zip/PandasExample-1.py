import pandas as pd
import matplotlib.pyplot as plt

emp = {'eid':[1,3,6,10,5],
       'name':['Nitin','Aman Gupta','Kshitiz Johar','Gaurav Kapoor','Monika'],
       'gender':['Male','Male','Male','Male','Female'],
       'country':['India','India','UK','Aus','Inidia']}


print(emp)
#create dataframe from dict
df = pd.DataFrame(data=emp)
print(df)

print(df.shape)
print(df.columns)
print(df.head(n=3))
print(df.tail(n=2))

print(df.info()) #object  : str, Int64  : numeric, float
print(df.describe()) #show stats of every numeric columns

#add new column in existing dataframe
df['salary'] = [45000,34000,90000,67000,41000]
print(df)

print(df.describe())

#group
print(df.groupby('country').size())
print(df.groupby('country').sum())
print(df.groupby('country').max())
print(df.groupby('country').min())
print(df.groupby('country').min()[['name','salary']])


##order by
print(df.sort_values('salary',ascending=True)) #in asc
print(df.sort_values('salary',ascending=False)) #in desc

#filter
print(df[df['salary']>50000])

#convert to list
x = df.values
print(x)

#graph or presentation
#df.plot()
#df.plot(kind='bar')
#df.plot(kind='box')
#df.plot(kind='bar',subplots=True)
df.plot(kind='bar',subplots=True,layout=(2,2))
plt.show()

##
#df.to_csv('employee_datta.csv')




