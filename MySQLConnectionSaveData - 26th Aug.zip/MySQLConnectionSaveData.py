
import mysql.connector as c

#establish the connection from ptthon to mysql db
con = c.connect(host='localhost',user='root',password='root',database='aug')

#
cur = con.cursor() #create object to execute sql command

cur.execute("insert into users(uid,name,email,salary) values(1,'raman','raman@gmail.com',950);")

con.commit()
print('data is saved')




