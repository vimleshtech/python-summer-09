from pandas import DataFrame
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


un_employment = [3,4,5,2,6,7,2]
ir = [10,9,8,12,7,4,10]
stock_price = [1200,1300,890,600,900,1500,1150]


    
df = DataFrame(data={'UNE':un_employment,'IR':ir,'SP':stock_price})

print (df)
x = df[['UNE','IR']]
y = df['SP']

reg = LinearRegression()
reg.fit(x,y)

print(reg.intercept_,reg.coef_)


#predict
ir = int(input('enter next year ir :'))
ue = int(input('enter next year ue :'))



print(reg.predict([[ue,ir]]))




