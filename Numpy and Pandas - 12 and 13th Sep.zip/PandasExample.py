#read csv
import pandas as pd

e = pd.read_csv(r'C:\Users\vkumar15\Documents\Sandbox\Excel\emp.csv')
print(e)

print(e.shape)
print(e.head()) #show from top 5 rows
print(e.tail(n=2))

#read selected columns
print(e['name'])

print(e[['name','gender']])

##convert dataframe to list
d = e.values
print(d)

#Q. wap to read data from csv which contains : sid name hs es cs ms
#and calculate : total , avg , grade


