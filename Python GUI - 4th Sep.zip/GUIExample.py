from tkinter import *
'''
--class
TK()
Label()
Entry()
Button()
--parameter or input
text
command

--method/function
pack()
'''
o = Tk()
o.title('Test  Form')

l1 = Label(text='Enter first name :')
l1.pack()
t1  = Entry()
t1.pack()

l2 = Label(text='Enter Last name :')
l2.pack()
t2  = Entry()
t2.pack()

out = Label()
out.pack()

def event():
    print('you have clicked on button')
    #read data from entry box
    fn = t1.get()
    ln = t2.get()
    full_name  = fn+' '+ln
    print('name is :',full_name)
    out.configure(text=full_name)
    
   
    
b1 = Button(text='Submit',command=event)
b1.pack()

    
o.mainloop()
