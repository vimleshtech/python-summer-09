import math


data = 6

print(math.pi)

print(math.factorial(data))

print(math.pow(4,5))
print(math.sqrt(9))



##
import random

print(random.random())

print(random.random())
print(random.random())

print(random.randint(1,10))

'''
fn ='raman'
ln ='sharma'
 
fn[1:3]+ str(random.randint(1,1000))+ln[-4:]

'''





