try:
     
     sales = int(input('enter sales amt :'))

     c = 0
     if sales>=1 and sales<=10000:
          c = sales*.04
     elif sales>10000 and sales <=20000:
          c = sales*.05
     elif sales>20000 and sales <=30000:
          c = sales*.06
     else:
          c = sales*.07

     print(c)

except:
     print('input is not valid , plz try again!!!')
     
