
a = int(input('enter data :'))

if a>10: #condition 
     print('a is greater than 10')
     #
     #
     #
     
else:
     print('a is less than 10')


     
