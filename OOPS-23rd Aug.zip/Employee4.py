from Employee3 import employee


class contractor(employee):
    def working_days(s):
        print('there are 6 working days.. from mon to sat ')
    def working_days(s,a):
        print('there are 6 working days.. from mon to sat  - a fun')


        
        

    
