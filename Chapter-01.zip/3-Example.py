x =int( input('enter data '))
y =int( input('enter data '))

z =x+y
print(z)

#print with message
print('sum of two numebrs :',z)

##
print('sum of ',x,' and ',y,' is :',z)

print('sum of {} and {} is {}'.format(x,y,z))

print('sum of {1} and {0} is {2}'.format(x,y,z)) #here 1,0 .. are index


