##
import time

t = time.localtime()

print(t)
print(t.tm_year)

print(t.tm_mon)

print(t.tm_mday)

print(t.tm_min)


print(t.tm_year,'-',t.tm_mon,'-',t.tm_mday)
