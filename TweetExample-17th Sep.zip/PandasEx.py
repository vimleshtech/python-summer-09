
import pandas as pd


#x = pd.read_csv()
x =pd.DataFrame(data={'eid':[1,2,3],'name':['jatin','divya','test']})
print(x)

x.columns = ["ecode","ename"]

print(x)



