from tkinter import *

o = Tk()

t1 = Entry()
t1.pack()

def new_form():
    o1= Tk()
    msg = t1.get()
    l1 = Label(o1,text=msg)
    l1.pack()
    o1.mainloop()
    
b1 = Button(text="Open New Form",command=new_form)
b1.pack()


o.mainloop()
