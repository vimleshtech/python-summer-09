class student:
    def input_data(self):
        self.rollno=int(input('enter rno:'))
        self.name=input('enter name:')
        self.address=input('enter address:')
        self.city=input('enter city:')
        self.country=input('enter country:')
    def get_rno(self):
        return self.rollno
    def dispdata(self):
        print('rno :',self.rollno)
        print('name :',self.name)
        print('address :',self.address)
        print('city :',self.city)
        print('country :',self.country)
        

e = []
for i in range(2):
    o = student()
    o.input_data()
    e.append(o)

print(o)

for i in range(len(e)):
    for j in range(i+1,len(e)):
        if e[i].get_rno() > e[j].get_rno():
            t = e[i]
            e[i] = e[j]
            e[j] = t

for o in e:
    o.dispdata()

print(len(e))

#search
rno = int(input('enter rno :'))
for i in range(len(e)):
    if e[i].get_rno() == rno:
        e[i].dispdata()
        
            


            
            



    
    
	

