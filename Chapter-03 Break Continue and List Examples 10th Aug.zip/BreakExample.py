i =1
while i<=10:
    if i% 3 ==0:
        break
    print(i)
    i =i+1
    
