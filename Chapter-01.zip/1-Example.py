a =      1
b                 =454

c=a+b

print(c)

#declare variables
a =44
b =555

x,y =555,333

m = a+b+x+y
print(m)





