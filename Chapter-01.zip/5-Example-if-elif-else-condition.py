#Python is indentation based language

amt =  int(input('enter sales amt :'))


tax = 0

if amt>10000:
     tax = amt*.18 #if condition is true 
elif amt>1000:
     tax = amt*.12 
elif amt>500:
     tax = amt*.05 
else:
     tax = amt*.02
     
     
     


total_amt = amt+tax
print('total amt is :',total_amt)


 
