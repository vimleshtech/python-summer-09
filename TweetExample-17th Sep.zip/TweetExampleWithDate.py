import tweepy
import textblob
import re

#from textblob import TextBlob #text/tweet parse

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"


auth = tweepy.OAuthHandler(ck, cs)
# set access token and secret
auth.set_access_token(at, ats)

# create tweepy API object to fetch tweets
api = tweepy.API(auth)

print('login pass')

out = api.search(q="Narendra Modi",count=2)
    
for t in out:
        try:
            print(t.created_at)
            print(type(t))
        except:
            pass



        
            
        
