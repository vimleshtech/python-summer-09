'''
File Hanlding: read and write operation from and with file
There are following inbuilt functions:

open(path,mode)
    path: physical location of file
    mode : r- read, w-write, a - append
read() : read all contenet from file
    
readline() : read first line /line by line
readlines() : read line all content and convert to list
             -every line of file will become one item of list
             
write()    : write content to file 
close()    : save the file 
'''
o = open('myfile.txt','w')
o.write('hi , this is my first file \n')
o.write('end of file ')

o.close()
print('file is saved')








