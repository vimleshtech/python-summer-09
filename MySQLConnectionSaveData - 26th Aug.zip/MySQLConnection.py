
import mysql.connector as c

#establish the connection from ptthon to mysql db
con = c.connect(host='localhost',user='root',password='root',database='aug')

#
cur = con.cursor() #create object to execute sql command

cur.execute('select * from users')

data = cur.fetchall()
#print(data)
for r in data:
    #print(r)
    print(r[1],r[2])
    





