def sq(n):
    return n*n
o = sq(10)
print(o)

def cube(n):
    return n*n*n
c = cube(2)
print(c)
def aoc(r):
    return 3.14*r*r

a = aoc(2)
print(a)

def aor(l,b):
    return l*b

a= aor(2,4)
print(a)

def si(p,r,t):
    return p*r*t/100

b = si(3,4,5)
print(b)


def even(n):
    if n/2==0:
        print(even(n))
    else:
        return 0

  
    
