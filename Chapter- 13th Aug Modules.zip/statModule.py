import statistics 

a = [111,222,444,555,3,3,333,555,3]

print(statistics.mean(a)) #avg 
print(statistics.mode(a)) #return value which has highest count /freq 

print(statistics.median(a))  #1 3 5 7 9 10 (mid value) 

#print(statistics.mean(a))

print(statistics.variance(a))

print(statistics.stdev(a))    #sqrt of var

print(statistics.median_high(a))
print(statistics.median_low(a))

#statistics.median_high()

