a = int( input('enter data :'))
b    =  int(input('enter data :'))


c =a+b
print(c)

###
#\t : tab
#\n : new line 
print('hi',end='\t')  #print and new line  by default
#end is keyword to replace the last char (from \n to other)

print('test') 

#sum of of two numbers
print('sum of two numebrs ',c)

#sum of a and b is c

print('sum of a and b is ',c)
print('sum of {} and {} is {}'.format(a,b,c))

print('sum of {1} and {0} is {2}'.format(a,b,c))




