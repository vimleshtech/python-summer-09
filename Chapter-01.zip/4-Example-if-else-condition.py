#Python is indentation based language

amt =  int(input('enter sales amt :'))


tax = 0

if amt>1000:
     tax = amt*.18 #if condition is true 
else:
     tax = amt*.12 #if condition is false 
     


total_amt = amt+tax
print('total amt is :',total_amt)


 
