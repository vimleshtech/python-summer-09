import numpy as np

a = np.arange(10) #generate array
print(a)
print(type(a))

#convert list to array
b = [11,222,44,55,663]
print(b)
print(type(b)) #list
x = np.array(b)
print(x)
print(type(x)) #array

#array operation
print(b*2) #list operation
print(x*2) #array array

##
print(x.shape)

print(np.zeros(10))
print(np.ones(10))

####
a = [[1,2,4,],[1,32,44,],[1,2,4,]]
b = [[11,2,41,],[1,2,4,],[1,2,4,]]
x = np.array(a)
y = np.array(b)
print(a)
print(a)

print(x)
print(y)

print(x.T) #tranpose 

#
print(np.add(x,y))
print(np.subtract(x,y))
print(np.multiply(x,y))
print(np.divide(x,y))

























