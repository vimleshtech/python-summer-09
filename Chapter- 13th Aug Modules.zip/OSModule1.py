
import os

o = os.listdir(r'C:\Users\hp\Desktop')
print(o)

print(len(o))

tc = 0
out = open(r'C:\Users\hp\Desktop\alldata.txt','w')

for r in o:
        #print(r)
        if r.endswith('.txt'):
                f = open(r'C:\Users\hp\Desktop\\'+r)
                #print(r'C:\Users\hp\Desktop\\'+r)
                
                #print(f.read())
                out.write(f.read())
                out.write('-----------------------------\n')

                
         
print(tc)
out.close()



                
                
