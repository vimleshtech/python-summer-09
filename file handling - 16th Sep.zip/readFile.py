o  = open(r'C:\Users\vkumar15\Documents\TestFolder\myfile.txt','r')

#print(o.read())
#read first line
#print(o.readline())

d = o.readlines()
print(d)

for r in d:
    print(r)
    


#Q. wap to get row count from file
#Q. wap to word count from file
    
    


    

