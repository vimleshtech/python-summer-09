import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy  as np


sid   = [1,2,3,4,5,6,7,8,9]
sname = ['Nitin','Jatin','Divya','Mohit','Rahul','Monika','Kshitz','Ridhi','Vidhi']
hours = [4,6,7,8,9,2,3,12,14]
marks = [33,56,63,82,80,31,27,82,98]

#create dataframe
df = pd.DataFrame(data={'sid':sid,'sname':sname,'hours':hours,'marks':marks})
print(df)

                    
#corr
print(df.corr())

#extract data (x,y)
x = df['hours']
y = df['marks']

print(x)
x = np.array(x).reshape(-1,1)
print(x)

#model
o = LinearRegression()
lm = o.fit(x,y)

print(lm)
print(lm.intercept_)
print(lm.coef_)


###predictions
nhours = []
for x in range(3):
    a = int(input('enter hours :'))
    nhours.append(a)

nhours = np.array(nhours).reshape(-1,1)

print(lm.predict(nhours))


      

    
    
    
    






