i =1 #init

while i<10: #condition 
     print(i)   #show message / data 
     i = i+1  #increment


#print in reverse order
i =10
while i>0:
     print(i)
     i =i-1
     


#wap(write a program) to print table of given no
n = 6
i =1
while i<=10:
     #print(n*i)
     print('{} * {} = {}'.format(n,i,n*i))
     i =i+1
     

#wap to print sum of all even no between 1 to 89
i =1
s = 0
while i<=89:
     if i % 2 ==0:
          s = s+i
          
     i =i+1
     
     
print('sum of all even numbers :',s)

     
     
