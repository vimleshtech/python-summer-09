#create class
class employee:
    #create function or  method 
    def newemp(self):  #def is keyword to define the function
        print(self)
        self.eid = input('enter eid :')  #default input type is str 
        self.name = input('enter name :')
        self.bsal = int(input('enter sal :'))
    def __init__(self):
        print('object is created ')
        
    def compute(a):
        print(a)
        a.hra = a.bsal*.40
        a.da = a.bsal*.20
        a.msal = a.hra+a.da + a.bsal
        a.ysal = a.msal*12       
        
    def disp(a):
        print(a)
        print('eid is ',a.eid)
        print('name is ',a.name)
        print('hra is ',a.hra)
        print('da is ',a.da)
        print('msal is ',a.msal)
        print('ysal is ',a.ysal)
        
#create object of class
emps = []
for i in range(5):
    
    o = employee()

    #print(o)
    o.newemp()
    o.compute()
    emps.append(o)


print(emps)
for x in emps:
     
    x.disp()
    

    
    

